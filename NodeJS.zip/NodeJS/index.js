require('dotenv').config();

const express = require('express');
const app = express();
const ejs = require('ejs');
const mongoose = require('mongoose');
const expressSession = require('express-session');
const User = require('./models/User');

// MongoDB Connection
mongoose.connect(process.env.MONGODB_URI, {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => {
    console.log("MongoDB Connected");
}).catch(err => {
    console.log("Failed to connect to MongoDB", err);
});

// Controllers
const indexController = require('./controllers/indexController')
const homeController = require('./controllers/homeController')
const registerController = require('./controllers/registerController')

app.use(express.static('public'))
app.use(express.json())
app.use(express.urlencoded({extended:false}))
app.use(expressSession({
    secret: "node secret",
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false }
}))
app.set('view engine', 'ejs')

app.get('/', indexController)
app.get('/home', homeController)
app.get('/register', registerController)
app.post('/register',async (req,res) => {
    const data={
        username:req.body.username,
        password:req.body.password
    }
    await User.insertMany([data])

    res.redirect("/")
})

app.post('/login',async (req,res) => {
    
    try {
        const check = await User.findOne({username:req.body.username})
        if (check.password === req.body.password) {
            req.session.username = req.body.username;
            res.redirect("/home")
        }else{
            res.send("Wrong password")
        }
    } catch (error) {
        res.send("Wrong username or password")
    }
})

app.get('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            return res.redirect('/home');
        }
        res.clearCookie('connect.sid');
        res.redirect('/');
    });
});

app.listen(4000, () => {
    console.log("App listening on port 4000");
})